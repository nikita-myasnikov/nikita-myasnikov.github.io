# Nikita Myasnikov — Developer Portfolio

Static production export for GitHub Pages. The GitHub Pages workflow deploys this archive to the site root. The full Nuxt source remains in the private `portfolio` repository.
